const { Router } = require('express')
const {} = require('../controladores').Transaccion;

const router = Router();

router.get('/',);
router.post('/',);

module.exports=router;