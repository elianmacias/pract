module.exports={
    'Transaccion' : require('./trans')
}

//