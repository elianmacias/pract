const validar = require('../middlewars/validar')

module.exports = {
    ...validar
}