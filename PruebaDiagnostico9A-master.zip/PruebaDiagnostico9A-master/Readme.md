## Prueba
![conexion Backend](./fotos/integrantes.png)
![conexion Backend](./fotos/backend%20.png)

![conexion Frontend](./fotos/frotend.png)


![docker compose up](./fotos/Basededatos.png)


![creacion imagenes](./fotos/docker.png)
![creacion imagenes](./fotos/docker1.png)


![crean contenedores](./fotos/mongo.png)

